//Author Name: Dylan Kusick

//Date: 7-16-23

//Course ID: CS-320-X6133

//Description: Contact service Java class that initializes an arraylist to store contacts.
			//Three methods, addContact, deleteContact, and updateContact

import java.util.ArrayList;

public class ContactService {


    private ArrayList<Contact> contacts; //Initialize array list

    public ContactService() {
        contacts = new ArrayList<>(); 
    }

    
    
    public boolean addContact(Contact contact) {			//ADD CONTACT
        boolean contactExists = false; //initialize Contact
        for (Contact contactList : contacts) {
            if (contactList.equals(contact)) { //If contact exists
                contactExists = true;
            }
        }
        if (!contactExists) { //If contact does not exist
            contacts.add(contact); //Add contact
            return true;
        } else {
            return false;
        }
        
    }  
    
    
    
    public boolean deleteContact(String string) {			//DELETE CONTACT
        for (Contact contactList : contacts) {
            if (contactList.getContactID().equals(string)) { //If contact exists
                contacts.remove(contactList); //Remove
                return true;
            }
        }
        return false;
    }

    
   
    
    
    public boolean updateContact(String contactID, String firstName, String lastName, String phoneNumber, String address) {  //UPDATE CONTACT
        for (Contact contactList : contacts) {
        	
            if (contactList.getContactID().equals(contactID)) {
                if (!firstName.equals("") && (firstName.length() <= 10)) {					//Update first name if valid
                    contactList.setFirstName(firstName);
                }
	                if (!lastName.equals("") && !(lastName.length() > 10)) {				//Update last name if valid
	                    contactList.setLastName(lastName);
	                }
		                if (!phoneNumber.equals("") && (phoneNumber.length() == 10)) {		//Update phone number if valid
		                    contactList.setPhoneNumber(phoneNumber);
		                }
			                if (!address.equals("") && !(address.length() > 30)) {			//Update address if valid
			                    contactList.setAddress(address);
			                }	   
			                
            return true; //Return true if one field is valid, such as contact ID. Update valid fields
            }
        }
        return false; //Return false if contactID is not valid
    }

}
