//Author Name: Dylan Kusick

//Date: 7-16-23

//Course ID: CS-320-X6133

//Description: JUnit test class for the contact service class. Tests the methods that add, delete, and updates contacts

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class ContactServiceTest {

    @Test
    public void testAdd() {								//Tests the addition of a contact
    	
        ContactService CS = new ContactService();
        Contact test = new Contact("1038342", "Fred", "Bauer", "4444444444", "123 Popcorn Drive");  
        assertEquals(true, CS.addContact(test));
        
    }
    

    
    
    
    
    @Test
    public void testDelete() {							//Tests the deletion of a contact
    	
        ContactService CS = new ContactService();
        Contact test = new Contact("1038342", "Fred", "Bauer", "4444444444", "123 Popcorn Drive"); 	//Pass in contact parameters
        CS.addContact(test);

        assertEquals(true, CS.deleteContact("1038342")); //Contact able to be deleted
        assertEquals(false, CS.deleteContact("2340895")); //Non-existent contact, expected to return false
        
    }

    
    
    
    
    @Test
    public void testUpdate() {							//Tests to see if the contact is able to be updated
    	
        ContactService CS = new ContactService();
        Contact test1 = new Contact("1038342", "Fred", "Bauer", "4444444444", "123 Popcorn Drive");      //Pass in contact parameters
        Contact test2 = new Contact("5736584", "Bob", "Beans", "2187123404", "151 Beans Road");			 //Contact id, first name, last name, phone number, address
        Contact test3 = new Contact("4589909", "Jill", "Will", "3547984578", "489 Fortnite Court");

        CS.addContact(test1);
        CS.addContact(test2);
        CS.addContact(test3);

        assertEquals(true, CS.updateContact("4589909", "Jill", "Will", "9215501793", "3298 Bandway")); //Expected to return true
        assertEquals(true, CS.updateContact("4589909", "Jill5678910", "Will5678910", "12345678910", "3298 Bandwayasdfasdfasdfasdfasdfasdfasd")); //Returns true only because there is a valid ID. Updates valid fields, in this case is none
        assertEquals(false, CS.updateContact("4589910", "Jill", "Will", "9215501793", "3298 Bandway")); //Expected to return false due to bad ID
        
    }


}
