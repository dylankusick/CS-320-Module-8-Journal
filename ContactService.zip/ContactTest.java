//Author Name: Dylan Kusick

//Date: 7-16-23

//Course ID: CS-320-X6133

//Description: JUnit test class for the contact class. Tests to make sure contactID, firstName, lastName, phoneNumber, and address are valid

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {
	
    @Test
    @DisplayName("Contact ID cannot have more than 10 characters")			//Tests to make sure the contact id is less than 10 characters  @DisplayName to display for each test
    void testContactIDWithMoreThanTenCharacters() {
        Contact contact = new Contact("contactID", "Dylan", "Kusick", "1234567898", "123 Popcorn Drive"); //Contact information
        if (contact.getContactID().length() > 10) {
            fail("Contact ID has more than 10 characters."); //Fail message
        }																													  //CONTACT ID VALIDATION
    }
    @Test
    @DisplayName("Contact ID cannot be null")								//Tests to make sure the contact id is not null
    void testContactIDNotNull() {
        Contact contact = new Contact("contactID", "Dylan", "Kusick", "1234567898", "123 Popcorn Drive"); //Contact information
        if (contact.getContactID().length() > 10) {
            fail("Contact ID is null."); //Fail message
        }
    }

    
    
    
    
    @Test
    @DisplayName("First Name cannot have more than 10 characters")	 //Tests to make sure the first name is not more than 10 characters
    void testContactFirstNameWithMoreThanTenCharacters() {
        Contact contact = new Contact("contactID", "Dylan", "Kusick", "1234567898", "123 Popcorn Drive"); //Contact information
        if (contact.getFirstName().length() > 10) {
            fail("First Name has more than 10 characters."); //Fail message
        }																														//FIRST NAME VALIDATION
    }
    @Test
    @DisplayName("First Name shall not be null")					  //Tests to make sure the first name is not null
    void testContactFirstNameNotNull() {	
        Contact contact = new Contact("contactID", "Dylan", "Kusick", "1234567898", "123 Popcorn Drive"); //Contact information
        assertNotNull(contact.getFirstName(), "First name was not null."); //Null assertion message
    }
    
    
    
    
    
    @Test
    @DisplayName("Last Name cannot have more than 10 characters")     //Tests to make sure the last name is less than 10 characters
    void testContactLastNameWithMoreThanTenCharacters() {
        Contact contact = new Contact("contactID", "Dylan", "Kusick", "1234567898", "123 Popcorn Drive"); //Contact information
        if (contact.getLastName().length() > 10) {
            fail("Last Name has more than 10 characters."); //Fail message
        }																														//LAST NAME VALIDATION
    }
    @Test
    @DisplayName("Last Name shall not be null")							//Tests to make sure the last name is not null
    void testContactLastNameNotNull() {
        Contact contact = new Contact("contactID", "Dylan", "Kusick", "1234567898", "123 Popcorn Drive"); //Contact information
        assertNotNull(contact.getLastName(), "Last name was null."); //Null assertion message
    }
    
    
    
    

    @Test
    @DisplayName("Phone number is exactly 10 characters")			  //Tests to make sure the phone number is exactly 10 characters
    void testContactNumberWithMoreThanTenCharacters() {
        Contact contact = new Contact("contactID", "Dylan", "Kusick", "1234567898", "123 Popcorn Drive"); //Contact information
        if (contact.getPhoneNumber().length() != 10) {
            fail("Phone number length is not 10 characters."); //Fail message
        }																														//PHONE NUMBER VALIDATION
    }
    @Test
    @DisplayName("Phone Number shall not be null")						//Tests to make sure the phone number is not null
    void testContactPhoneNotNull() {
        Contact contact = new Contact("contactID", "firstName", "lastName", "1234567898", "123 Popcorn Drive"); //Contact information
        assertNotNull(contact.getPhoneNumber(), "Phone number was null."); //Null assertion message
    } 

    
    
    
    
    @Test
    @DisplayName("Address cannot be more than 30 characters")		  //Tests to make sure the address is not more than 30 characters
    void testContactAddressWithMoreThanThirtyCharacters() {
        Contact contact = new Contact("contactID", "Dylan", "Kusick", "1234567898", "123 Popcorn Drive"); //Contact information
        if (contact.getAddress().length() > 30) {
            fail("Address is more than 30 characters."); //Fail message
        }																															//ADDRESS VALIDATION
    }
    @Test
    @DisplayName("Address shall not be null")							//Tests to make sure the address is not null
    void testContactAddressNotNull() {
        Contact contact = new Contact("contactID", "Dylan", "Kusick", "1234567898", "123 Popcorn Drive"); //Contact information
        assertNotNull(contact.getAddress(), "Address is null."); //Null assertion message
    }

}
